export default function Loader(){
  return <>
<div class="cssload-loader">
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
	<div class="cssload-side"></div>
</div>
  </>
}